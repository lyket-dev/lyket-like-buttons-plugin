=== Lyket like buttons ===
Contributors: souljuse
Website: https://lyket.dev
Registration link: https://app.lyket.dev/signup
Tags: like button, clap button, like/dislike button
Requires at least: 1.0
Tested up to: 5.7
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lyket like buttons lets you add beautiful clap, like and dislike buttons on your Wordpress website.

== Description ==

With Lyket you can create beautiful and customizable like buttons for your website.

Read the full documentation on [the official page](https://lyket.dev/docs/wordpress)

== Frequently Asked Questions ==

= Do I need to register? =

Yes, to use Lyket you need to signup on [the official page](https://app.lyket.dev/signup), and copy your API key in Lyket's plugin settings in WordPress.

= Can I suggest any changes or report bugs? =

Of course! Feel free to write to our [support](mailto:lyket.dev@gmail.com)

== Changelog ==

Changes are thoroughly documented on [the official repo of the project](https://github.com/lyket-dev/lyket/blob/master/CHANGELOG.md)
